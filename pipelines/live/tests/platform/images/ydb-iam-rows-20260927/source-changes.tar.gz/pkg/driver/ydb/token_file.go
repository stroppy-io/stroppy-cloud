package ydb

import (
	"context"
	"errors"
	"fmt"
	"io"
	"os"
	"strings"
	"sync"
	"time"

	"go.uber.org/zap"
)

const maxAuthTokenBytes = 16 * 1024

var errInvalidTokenFile = errors.New("YDB token file must contain a nonempty token of at most 16384 bytes")

// tokenFileCredentials reloads an atomically replaced plaintext token file.
// Cache for one second so authentication does not add filesystem IO to every
// benchmark query. An unreadable/empty file fails closed after that interval.
type tokenFileCredentials struct {
	mu       sync.Mutex
	path     string
	token    string
	nextRead time.Time
	now      func() time.Time
	logger   *zap.Logger
}

func (*tokenFileCredentials) String() string { return "ydb token-file credentials" }

func (c *tokenFileCredentials) Token(ctx context.Context) (string, error) {
	if err := ctx.Err(); err != nil {
		return "", err
	}

	c.mu.Lock()
	defer c.mu.Unlock()

	now := c.now()
	if now.Before(c.nextRead) && c.token != "" {
		return c.token, nil
	}

	f, err := os.Open(c.path)
	if err != nil {
		return "", fmt.Errorf("read YDB token file: %w", err)
	}
	defer f.Close()

	b, err := io.ReadAll(io.LimitReader(f, maxAuthTokenBytes+1))
	if err != nil {
		return "", fmt.Errorf("read YDB token file: %w", err)
	}

	token := strings.TrimSpace(string(b))
	if token == "" || len(b) > maxAuthTokenBytes {
		return "", errInvalidTokenFile
	}

	if c.token != token && c.logger != nil {
		c.logger.Info("YDB authentication token loaded from file")
	}

	c.token, c.nextRead = token, now.Add(time.Second)

	return token, nil
}
