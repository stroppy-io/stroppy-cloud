package ydb

import (
	"context"
	"net"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	discoveryservice "github.com/ydb-platform/ydb-go-genproto/Ydb_Discovery_V1"
	"go.uber.org/zap"
	"google.golang.org/grpc"

	"github.com/stroppy-io/stroppy/pkg/config"
	"github.com/stroppy-io/stroppy/pkg/driver"
)

func TestTokenFileReloadsAtomicReplacementAndFailsClosed(t *testing.T) {
	path := filepath.Join(t.TempDir(), "iam-token")
	now := time.Now()
	c := &tokenFileCredentials{path: path, now: func() time.Time { return now }, logger: zap.NewNop()}
	write := func(value string) {
		t.Helper()

		if err := os.WriteFile(path+".next", []byte(value), 0o600); err != nil {
			t.Fatal(err)
		}

		if err := os.Rename(path+".next", path); err != nil {
			t.Fatal(err)
		}
	}
	write("first-secret\n")

	got, err := c.Token(t.Context())
	if err != nil || got != "first-secret" {
		t.Fatalf("initial token: %v", err)
	}

	write("second-secret")

	now = now.Add(2 * time.Second)

	got, err = c.Token(t.Context())
	if err != nil || got != "second-secret" {
		t.Fatalf("updated token: %v", err)
	}

	if strings.Contains(c.String(), "secret") {
		t.Fatal("credentials formatter disclosed a token")
	}

	for _, bad := range []string{"", strings.Repeat("s", 16385)} {
		write(bad)

		now = now.Add(2 * time.Second)

		got, err = c.Token(t.Context())
		if err == nil || got != "" {
			t.Fatal("invalid file reused a cached credential")
		}
	}

	if err := os.Remove(path); err != nil {
		t.Fatal(err)
	}

	got, err = c.Token(t.Context())
	if err == nil || got != "" {
		t.Fatal("missing file reused a cached credential")
	}

	ctx, cancel := context.WithCancel(t.Context())
	cancel()

	got, err = c.Token(ctx)
	if err == nil || got != "" {
		t.Fatal("canceled context returned a token")
	}
}

func TestExplicitTokenFileDoesNotFallBackToMetadata(t *testing.T) {
	listener, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}

	server := grpc.NewServer()
	discoveryservice.RegisterDiscoveryServiceServer(server, &rejectedDiscovery{})

	t.Cleanup(server.Stop)
	go func() { _ = server.Serve(listener) }()

	path := filepath.Join(t.TempDir(), "missing-token")

	_, err = NewDriver(t.Context(), driver.Options{
		Config: &config.DriverConfig{
			URL: "grpc://" + listener.Addr().String() + "/?database=/test", AuthTokenFile: &path,
		},
		Logger: zap.NewNop(),
	})
	if err == nil || !strings.Contains(err.Error(), "read YDB token file") {
		t.Fatalf("expected token file failure, got %v", err)
	}

	if strings.Contains(err.Error(), "yc metadata fallback") {
		t.Fatalf("changed explicit credential identity: %v", err)
	}
}
