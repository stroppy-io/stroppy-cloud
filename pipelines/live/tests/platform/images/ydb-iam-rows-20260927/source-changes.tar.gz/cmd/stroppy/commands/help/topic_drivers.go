package help

//nolint:gosec // help text contains example default credentials for local development
func init() {
	Register(Topic{
		Name:  "drivers",
		Short: "Driver presets, options, and multi-driver configuration",
		Long: `DRIVERS

  Stroppy is a single self-contained Go binary. Driver configuration flows
  directly from CLI flags (or a config file) into the benchmark engine.

DRIVER PRESETS (-d / --driver)

  A preset is a named shorthand that sets driverType and a default local URL.

    pg       driverType=postgres
             url=postgres://postgres:postgres@localhost:5432
             pgxpool-based; supports plain_query, plain_bulk, native (COPY)

    mysql    driverType=mysql
             url=myuser:mypassword@tcp(localhost:3306)/mydb
             sql.DB-backed via sqldriver; default plain_bulk

    pico     driverType=picodata
             url=postgres://admin:T0psecret@localhost:1331
             sql.DB-backed; Begin() always errors — use isolation "none"

    ydb      driverType=ydb
             url=grpc://localhost:2136/local
             sql.DB-backed; native maps to BulkUpsert (use grpc:// or grpcs://)

    noop     driverType=noop
             url=noop://localhost
             discards all I/O; benchmarks stroppy's own overhead

  Each preset includes default credentials for local development.
  Use -D url=... to override the connection URL.

  CSV is the "csv" driver type with no short preset. It dumps
  generated rows instead of talking to a database. Configure it directly:

    stroppy run tpcb/tx -D driverType=csv \
      -D url='/tmp/tpcb-csv?merge=true&workload=tpcb' \
      --steps drop_schema,create_schema,load_data

  The CSV driver supports typed InsertRequest loads only. It accepts DDL in
  setup steps, rejects runtime query execution, and requires the native insert
  method.

  Use -d (driver 0) or -d1, -d2, ... for additional drivers:

    stroppy run tpcc/tx -d pg              # driver 0 = pg preset
    stroppy run tpcc/tx -d pg -d1 mysql    # driver 0 = pg, driver 1 = mysql

  Instead of a preset name, -d also accepts a raw JSON driver config:

    stroppy run tpcc/tx -d '{"url":"postgres://prod:5432","driverType":"postgres"}'

  Useful when no preset matches or many fields must be set at once. Raw JSON is
  validated recursively: field names must use exact lower-camel spelling or the
  former snake_case alias, and duplicate/colliding/unknown fields are rejected.

DRIVER OPTIONS (-D / --driver-opt)

  Override individual fields for a driver. Applies on top of a preset (if
  any), so fields not mentioned keep their preset values.

  Format:  -D key=value
  Numbered: -D1 key=value  (driver 1), -D2 key=value  (driver 2), etc.

  Available option keys:

    url                    string    Database connection URL
    driverType             string    postgres | mysql | picodata | ydb |
                                     noop | csv
    bulkSize               int       Rows per bulk INSERT (default: 2500)
    insertProgress.enabled bool      Enable load progress watcher
    insertProgress.interval duration Progress log/metric cadence (default: 10s)
    insertProgress.stallAfter duration Warn after no row progress (default: 60s)
    insertProgress.mode    string    off | log | metrics | both
    pool.maxConns          int       Maximum pool connections
    pool.minConns          int       Minimum pool connections
    pool.maxConnLifetime   duration  Max connection lifetime  (e.g. "1h")
    pool.maxConnIdleTime   duration  Max idle connection time (e.g. "10m")
    postgres.*             subfields PostgreSQL-specific pool config
    sql.*                  subfields sql.DB-generic pool config

  TLS / Authentication options:

    caCertFile             string    Path to CA certificate PEM file
    authToken              string    Authentication token (e.g., IAM token)
    authTokenFile          string    Reloadable plaintext YDB token file (within 1s; takes precedence over authToken)
    authUser               string    Username for static credentials auth
    authPassword           string    Password for static credentials auth
    tlsInsecureSkipVerify  bool      Skip TLS cert verification (testing only)
    defaultInsertMethod    string    Fallback for load requests without a method

  TLS is enabled automatically when the URL uses a secure scheme (e.g.
  grpcs:// for YDB). The options above are only needed when the server uses
  a private CA or requires authentication.

  pool.* options are sugar — they map to the driver-specific pool config
  (pgx pool or sql pool) based on driverType. They are ignored for noop/csv.

  defaultInsertMethod is used only when a workload leaves its load request's
  method unset. A workload-selected method always takes precedence.

HOW IT WORKS

  1. CLI flags (-d, -D) and config-file drivers are parsed into the selected
     Go driver's runtime configuration.

  2. Each DriverConfig is passed directly to the Go-native bench engine,
     which dispatches to the registered driver implementation.

  Drivers classify backend errors into bounded, database-independent facts.
  Workloads—not driver configuration—choose whether each transaction fact is
  retried, returned as an error, ignored, or made fatal. The former errorMode
  driver field has been removed; config files, raw driver JSON, and -D reject it.

ERROR AND EXIT BEHAVIOR

  Transaction errors follow the workload's retry policy. A retry attempt is
  counted separately; if a later attempt succeeds, the iteration succeeds and
  the run is not marked as completed with errors. A terminal nonfatal error
  fails that iteration, increments terminal/failed-iteration metrics, and the
  VU continues with its next iteration.

  Query-set workloads (TPC-H, TPC-DS, and execute_sql) continue with the next
  query after a nonfatal query error. They increment terminal/failed-query
  metrics without logging every duplicate event.

  The first occurrence of each bounded operation/error-class group is logged
  at WARN, recurring events are reported periodically as aggregates, and the
  final summary prints "completed with errors" with terminal errors, failed
  iterations, failed queries, retries, and representative groups. Nonfatal
  errors leave the process exit status at 0.

  Setup failures, workload or driver teardown failures, and fatal workload
  actions return a nonzero status. TPC-H and TPC-DS SF=1 answer comparison
  remains diagnostic: query errors and answer differences are logged but do not
  change exit status. A fatal action stops the whole scenario and is reported
  once. SIGINT/SIGTERM cancellation stops the scenario, runs teardown, and keeps
  its signal-derived exit status (130/143; a forced second signal is 2).
  Cancellation is not reported as a nonfatal benchmark error.

  To inspect the driver insert methods each driver supports:

    stroppy probe

EXAMPLES

  # PostgreSQL preset (tx — raw transactions; works on pg/mysql/pico/ydb)
  stroppy run tpcc/tx -d pg

  # Preset with URL override
  stroppy run tpcc/tx -d pg -D url=postgres://prod-host:5432/mydb

  # Two drivers: PostgreSQL and MySQL
  stroppy run tpcc/tx -d pg -d1 mysql

  # Dump generated TPC-B data to CSV and stop before the workload phase
  stroppy run tpcb/tx -D driverType=csv \
    -D url='/tmp/tpcb-csv?merge=true&workload=tpcb' \
    --steps drop_schema,create_schema,load_data

  # Pool tuning
  stroppy run tpcc/tx -d pg -D pool.maxConns=20 -D pool.maxConnLifetime=30m

  # Show load progress every 30 seconds and warn after 2 minutes idle
  stroppy run tpcc/tx -d pg -D insertProgress.interval=30s \
    -D insertProgress.stallAfter=2m

  # Full JSON config instead of preset
  stroppy run tpcc/tx -d '{"url":"postgres://prod:5432","driverType":"postgres"}'

  # YDB with TLS and token auth (grpc:// or grpcs:// scheme)
  stroppy run tpcc/tx -d ydb -D url=grpcs://host:2135/db \
    -D caCertFile=./certs/ca.pem -D authToken=t1.xxx...

  # YDB with static credentials
  stroppy run tpcc/tx -d ydb -D url=grpcs://host:2135/db \
    -D authUser=admin -D authPassword=secret

  # List driver insert methods
  stroppy probe

SEE ALSO

  stroppy run --help
  stroppy probe --help
  stroppy help config-file   (file-based driver config with full pool/TLS support)
`,
	})
}
