//go:build integration

package integration

import (
	"context"
	"os/exec"
	"regexp"
	"strconv"
	"strings"
	"testing"
	"time"
)

func TestTPCDSGeneratedPostgresAllQueries(t *testing.T) {
	pool := NewTmpfsPG(t)
	ResetSchema(t, pool)
	out := runStroppy(t, 5*time.Minute,
		"run", "tpcds", "-d", "pg", "-D", "url="+envOr(envTmpfsURL, defaultTmpfsURL),
		"--scale-factor", "0.01", "--query-stream", "0", "--query-seed", "19620718",
		"--executor", "shared-iterations", "--iterations", "1", "--vus", "1",
	)
	matches := regexp.MustCompile(`\[tpcds\] query(\d+)(?:_[abc])?: ok`).FindAllStringSubmatch(out, -1)
	if len(matches) != 103 {
		t.Fatalf("got %d successful SQL statements, want 103\n%s", len(matches), out)
	}
	seen := make(map[string]bool)
	for _, match := range matches {
		seen[match[1]] = true
	}
	for i := 1; i <= 99; i++ {
		if !seen[strconv.Itoa(i)] {
			t.Errorf("Q%d missing", i)
		}
	}
}

func TestTPCDSIncompleteMySQLFailsBeforeSchemaChanges(t *testing.T) {
	db := NewMySQL(t)
	ResetMySQL(t, db, []string{"customer"})
	if _, err := db.ExecContext(t.Context(), "CREATE TABLE customer (marker INT NOT NULL)"); err != nil {
		t.Fatal(err)
	}
	if _, err := db.ExecContext(t.Context(), "INSERT INTO customer VALUES (123)"); err != nil {
		t.Fatal(err)
	}
	repo, binary := stroppyBinary(t)
	ctx, cancel := context.WithTimeout(t.Context(), time.Minute)
	defer cancel()
	cmd := exec.CommandContext(ctx, binary, "run", "tpcds", "-d", "mysql",
		"-D", "url="+envOr(envMySQLAllURL, defaultMySQLAllURL),
		"--scale-factor", "0.01", "--query-stream", "0",
		"--executor", "shared-iterations", "--iterations", "1")
	cmd.Dir = repo
	out, err := cmd.CombinedOutput()
	if err == nil || !strings.Contains(string(out), "generated query set is incomplete") {
		t.Fatalf("expected explicit preflight failure, got %v\n%s", err, out)
	}
	var marker int
	if err := db.QueryRowContext(t.Context(), "SELECT marker FROM customer").Scan(&marker); err != nil || marker != 123 {
		t.Fatalf("preflight modified the existing schema: marker=%d, err=%v", marker, err)
	}
}
